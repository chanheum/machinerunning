
/***********************************************************************
 * Copyright (c)  2017 - 2020, Unicmicro Co.,Ltd .
 * All rights reserved.
 * Filename    : bsp_spi.h
 * Description : bsp_spi.h
 * Author(s)   : Dan
 * version     : V1.0
 * Modify date : 2019-02-21
 ***********************************************************************/

#ifndef __BSP_SPI_H__
#define __BSP_SPI_H__

#include	"config.h"

#define USE_HARDWARE_SPI			0 // 0--不使用硬件SPI，1--使用硬件SPI

#define SPI_3_WIRE					3 // SPI使用3线制通信
#define SPI_4_WIRE					4 // SPI使用4线制通信

#define UM2052_SPI_NWIRE			SPI_3_WIRE // 使用几线制SPI通信方式

#define NOP_DELAY()					_nop_();//__NOP();__NOP();

/*******************对应测试板的RF-B端口定义***********************/
#define UM2052_CSN_P			P17  /* UM2002的SPI使能引脚 */
#define UM2052_CLK_P       		P15  /* UM2002的SPI时钟引脚 */
//#define UM2052_MOSI_P         P13  /* UM2002的SPI的输出引脚 */
//#define UM2052_MISO_P         P14	 /* UM2002的SPI输入引脚 */
#define UM2052_SDIO_P         	P13

/****************************************************************/

/***********************软件模拟SPI操作时每一个IO口的控制，SDIO是3线SPI时用的**********************/
#define UM2052_CSN_H()					do{ NOP_DELAY(); UM2052_CSN_P = 1;   NOP_DELAY();}while(0)
#define UM2052_CSN_L()					do{ NOP_DELAY(); UM2052_CSN_P = 0;   NOP_DELAY();}while(0) 
//#define UM2052_MOSI_H()					do{ NOP_DELAY(); UM2052_MOSI_P = 1;  NOP_DELAY();}while(0) 
//#define UM2052_MOSI_L()					do{ NOP_DELAY(); UM2052_MOSI_P = 0;  NOP_DELAY();}while(0)
#define UM2052_SDIO_H()					do{ NOP_DELAY(); UM2052_SDIO_P = 1;  NOP_DELAY();}while(0)
#define UM2052_SDIO_L()					do{ NOP_DELAY(); UM2052_SDIO_P = 0;  NOP_DELAY();}while(0)
#define UM2052_CLK_H()					do{ NOP_DELAY(); UM2052_CLK_P = 1;   NOP_DELAY();}while(0)
#define UM2052_CLK_L()					do{ NOP_DELAY(); UM2052_CLK_P = 0;   NOP_DELAY();}while(0) 

#define UM2052_Reag_MISO()				(UM2052_MISO_P)    
#define UM2052_Reag_SDIO()				(UM2052_SDIO_P) 

#define UM2052_CS_HIGH()				UM2052_CSN_H()
#define UM2052_CS_LOW()					UM2052_CSN_L()	
/****************************************************************/

/*********************涉及到最底层的操作函数***********************/
// 4线SPI读写1字节数据操作函数
unsigned char spi_4wire_wrd(unsigned char Data);
// 3线SPI写1字节数据操作函数
void SPI_3wire_sendByte(unsigned char TxData);
// 3线SPI读1字节数据操作函数
unsigned char SPI_3wire_readByte(void);
// UM2052 模拟SPI(3,4线)接口初始化函数
void UM2052_SPI_Init(void);
// UM2052 硬件SPI(4线)接口初始化函数
void hard_spi_init(void);

// 封装起来对外用的SPI写1字节数据操作函数
void SPI_SendByte(unsigned char dat);
// 封装起来对外用的SPI读1字节数据操作函数
unsigned char SPI_ReadByte(void);

// UM2052 直接写命令的函数
void UM2052_Operation(unsigned char opt);
// UM2052 写一个寄存器一个值的函数
void UM2052_write_byte(unsigned char addr,unsigned char D);
// UM2052 写一个寄存器多个值的函数
void UM2052_wr_buffer(unsigned char addr,const unsigned char* buf,unsigned char len);
// UM2052 读一个寄存器一个值的函数
unsigned char UM2052_read_byte(unsigned char addr);
// UM2052 读一个寄存器多个值的函数
void UM2052_read_buffer(unsigned char addr, unsigned char* buf, unsigned char len);

// 简单测试
void Sample_SPI_PS(void);
#endif 
