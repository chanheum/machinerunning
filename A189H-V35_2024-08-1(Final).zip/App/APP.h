
#ifndef __APP_H_
#define __APP_H_

//========================================================================
//                                ͷ�ļ�
//========================================================================

#include	"APP_Lamp.h"
#include	"APP_log.h"
#include	"APP_LED_Display.h"
#include	"APP_WDT.h"
#include	"APP_KEY.h"
//#include	"APP_SPI_PS.h"
#include 	"bsp_UM2052.h"
#include 	"radio24G.h"
#include 	"bsp_spi.h"
#include 	"APP_RF_TXRX.h"
#include 	"APP_Show_Display.h"

//extern u8  hour,minute,second; //RTC����
//extern u16 msecond;

void APP_config(void);

#endif
