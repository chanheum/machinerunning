#ifndef __radio24G_H__
#define __radio24G_H__

unsigned char Radio24G_Init(void);

void Radio_Send(uint8_t *pData, uint8_t tLen);
uint8_t Radio_Recv(uint8_t *pData);
void Radio24G_Config_Rx(void);

void Radio_GoRx(void);

void send_carrier_test(uint8_t ch);  // 发送载波
void UM2052_Dump_RF_Register(void);  // 打印所有的寄存器配置信息，，这个不需要移植到产品上，调试的时候可以用

#endif
