
// 20240729 v34


#ifndef _COWAY_DISPLAY_H_
#define _COWAY_DISPLAY_H_

typedef unsigned char   U8;     //  8 bits 
typedef unsigned int    U16;    // 16 bits 
typedef unsigned long   U32;    // 32 bits 

#define PROGRAM_VER 34U


//#define CONFIG_TEST

/***** Define *****/
//#ifndef TRUE
//#define TRUE 1U
//#endif

//#ifndef FALSE
//#define FALSE 0U
//#endif

#ifndef SET
#define SET 1U
#endif

#ifndef CLEAR
#define CLEAR 0U
#endif

#ifndef ON
#define ON 1U
#endif

#ifndef OFF
#define OFF 0U
#endif

#ifndef N_ON
#define N_ON 0U
#endif

#ifndef N_OFF
#define N_OFF 1U
#endif



#ifdef C_NULL
#undef	C_NULL
#endif
#define	C_NULL	((void *)0)

#define ASCII_STX   0x02
#define ASCII_ETX   0x03

#define GET_DECIMAL_10(val) (U8)((val)/10U)
#define GET_DECIMAL_1(val)  (U8)((val)%10U)

// Display List
typedef void (*Action_T)( void );
typedef struct _display_
{
    U8 Id;
    U8 Manual;
    U8 Focus;
    U8 Auto;
    U8 Fix;
    U8 Str;
    U8 Heat;
    U8 Course;
    U8 Step;
    U8 Min;
    U8 Key;
    Action_T Func;
} DisplayList_T;


typedef enum
{
    ID_NULL = 0U,
        
    ID_POWER_ONOFF, // 1
    ID_PAUSE,       // 2
    ID_AUTO,        // 3
    ID_MANUAL,      // 4
    ID_BALL_DN,     // 5
    ID_STR,         // 6
    ID_LEG_UP,      // 7
    ID_LEG_DN,      // 8
    ID_BALL_FIX,    // 9
    ID_MOVE_0G,     // 10
    ID_ADD_TIME,    // 11
    ID_SOUND,       // 12
    ID_BALL_UP,     // 13
    ID_HEAT,        // 14
    ID_BACK_DN,     // 15
    ID_BACK_UP,     // 16
    ID_FOCUS,       // 17
    ID_SWING,       // 18

    ID_PARING_SET,  // 19 (long) Auto + Heat
    ID_PARING_CLR,  // 20 (long) Manual + Heat    
    ID_SKIP,        // 21 (long) Time + Sound
    ID_ETC,         // 22 (long) Str + Heat
    ID_TEST,        // 23 (long) Pause + Time
    ID_VER,         // 24 (long) Pause + Sound

    //ID_ETC1,    // 19 (long) Pause + Str
    //ID_ETC2,     // 20 (long) Pause + Heat
        
    MAX_ID_NUM

} Key_Id_T;
/*
// resister raw data
test -> start/stop + str : 00 22
version -> start/stop + heat : 20 02
etc1 -> start/stop + time : 04 02
etc2 -> start/stop + sound : 08 02
paring -> time + sound : 0C 00

// remote -> coway_display  : Keybuf
KEY_Paring, //K17
KEY_Test,   //K18
KEY_Version,//K19
KEY_Etc1,   //K20
KEY_Etc2,   //K21

// remote -> main
#define KEY_Paring 0XC00000
#define KEY_Test 0X120000
#define KEY_Version 0X220000
#define KEY_Etc1 0X420000
#define KEY_Etc2 0X820000
*/
/*
u32 code KEY_DATA_corre[] = 
{
	KEY_Power,	//K1
	KEY_Pause,	//K2
	KEY_AT,		//K3
	KEY_MT,		//K4
	KEY_BallDW,	//K5
	KEY_Str,	//K6
	KEY_LegUP,	//K7
	KEY_LegDW,	//K8
	KEY_MSGBall,//K9
	KEY_Zero,	//K10
	KEY_Time,	//K11
	KEY_Vol,	//K12
	KEY_BallUP,	//K13
	KEY_Heat,	//K14
	KEY_BackDW,	//K15
	KEY_BackUP,	//K16
};
*/
typedef enum
{
    E_BACK_OFF = 0x00U,
    E_BACK_ON,

    MAX_BACKLIGHT_NUM
} Backlight_T;

typedef enum
{
    E_LED_OFF = 0x00U,
    E_LED_ON,

    MAX_LED_NUM
} Led_T;

typedef enum
{
    E_DIGIT_NULL = 0x00U,
    E_DIGIT_HI,
    E_DIGIT_OFF,
    E_DIGIT_START,
    E_DIGIT_STOP,
    E_DIGIT_AUTO,
    E_DIGIT_PASSIVE,
    E_DIGIT_STR,
    E_DIGIT_TIME,
    E_DIGIT_HEAT,
    E_DIGIT_BALL_UP,
    E_DIGIT_BALL_FIX,
    E_DIGIT_BALL_DN,

    MAX_DIGIT_NUM
} Digit_T;

typedef enum
{
    E_SEG_0 = 0x00U,
    E_SEG_1,
    E_SEG_2,
    E_SEG_3,
    E_SEG_4,
    E_SEG_5,
    E_SEG_6,
    E_SEG_7,
    E_SEG_8,
    E_SEG_9,
    
    E_SEG_A, // 10
    E_SEG_b, // 11
    E_SEG_C, // 12
    E_SEG_d, // 13
    E_SEG_E, // 14
    E_SEG_F, // 15
    E_SEG_G, // 16
    E_SEG_H, // 17
    E_SEG_I, // 18
    E_SEG_J, // 19
    E_SEG_K, // 20
    E_SEG_L, // 21
    E_SEG_m, // 22
    E_SEG_n, // 23
    E_SEG_o, // 24
    E_SEG_P, // 25
    E_SEG_q, // 26
    E_SEG_r, // 27
    E_SEG_S, // 28
    E_SEG_t, // 29
    E_SEG_U, // 30
    E_SEG_v, // 31
    E_SEG_w, // 32
    E_SEG_X, // 33
    E_SEG_y, // 34
    E_SEG_Z, // 35

    E_SEG_DASH, // 36 -
    E_SEG_DP,   // 37 DP .
	E_SEG_NULL, // 38 //null
	E_SEG_ALL,  // 39 0xff
	E_SEG_UNDERDASH,    // 40 _ 0x08
	E_SEG_UPDASH,     // 41 0x01

    MAX_SEG_NUM
} Seg_T;

/*
unsigned char code smgduan[]=
{
	0x3F,// 0
	0x06,// 1
	0x5B,// 2
	0x4F,// 3
	0x66,// 4
	0x6D,// 5
	0x7D,// 6
	0x07,// 7
	0x7F,// 8
	0x6F,// 9
	0x77,// A  10
	0x7C,// b  11
	0x39,// C  12
	0x5E,// d  13
	0x79,// E  14
	0x71,// F  15
	0x3D,// G  16
	0x76,// h  17
	0x04,// i  18
	0x0E,// J  19
	0x70,// K  20
	0x38,// L  21
	0x55,// m  22
	0x54,// n  23
	0x5C,// o  24
	0x73,// P  25
	0x67,// q  26
	0x50,// r  27
	0x6D,// S  28
	0x78,// t  29
	0x3E,// U  30
	0x1C,// v  31
	0x1D,// w  32
	0x76,// X  33
	0x72,// y  34
	0x49,// Z  35

	0x40,// -  		36
	0x80,// DP . 	37
	0x00,//null 	38
	0xff,//ALL  	39
	0x08,// _  		40
	0x01,// ``  	41
	};
*/

/*
typedef struct
{
	uint8_t 	Head;		//
	uint8_t 	Ver;		//
	uint8_t 	Data0_Power;
	uint8_t 	Data1_State;
	uint8_t 	Data2_Mode;
	uint8_t 	Data3_Strength;
	uint8_t 	Data4_Time;
	uint8_t 	Data5_Heat;
	uint8_t 	Data6_Volume;
	uint8_t 	Data7_Ball_state;
	uint8_t 	Data8_Error;
	uint8_t 	SUM;
	uint8_t 	Tial;
} Wireless_RX_struct;
extern Wireless_RX_struct 	Wireless_RX;
*/


// iRest Used Function
void CowayProcess ( void ); // 100ms
void SetKeyInput ( U8 mKey, U8 mLowB );
void SetKeyPushing ( void );
void SetKeyOff ( void );
U8 GetCowayDisplayBack ( void );
U8 GetCowayDisplay0 ( void );
U8 GetCowayDisplay1 ( void );
U8 GetCowayDisplay2 ( void );
U8 GetCowayDisplay3 ( void );
void SetCowayData ( U8* pBuf );
void SetCowayPid ( U8* pBuf );



#endif
