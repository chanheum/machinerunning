
#include	"APP.h"

void Radio24G_Config(void);

unsigned char Radio24G_Init(void)
{
	UM2052_SPI_Init();
	UM2052_Init();
	
	// �жϳ�ʼ���Ƿ�ɹ�---------------------------
	UM2052_CE_Low();
	UM2052_write_byte(UM2052_BANK0_RF_CH, 5); //
	delay_ms(3);
	if(5 != UM2052_read_byte(UM2052_BANK0_RF_CH)) 
	{
		return 0;
	}
	
	UM2052_write_byte(UM2052_BANK0_RF_CH, 0); // �����ŵ�
	
	UM2052_CE_High();	
	//-----------------------------------------------
	
	Radio24G_Config();  // ����
	
	UM2052_CE_Low();	
//	UM2052_Dump_RF_Register();
	return 1;
}

// ��������
void Radio24G_Config(void)
{
	UM2052_CE_Low();

	UM2052_write_byte(UM2052_BANK0_FEATURE, 0x10); // ��Щ���ö�����CE���͵�״̬�½��е�
	UM2052_write_byte(UM2052_BANK0_EN_AA, 0x00);   // �Ƿ�ʹ���Զ�Ӧ��
	UM2052_write_byte(UM2052_BANK0_CONFIG, 0xfa);  // config�Ĵ������λ��1������λ������Ҫ���ã���������ж�ӳ�䵽IRQ�ţ���ΪIRQ���ܻ�Ҫ�����ʹ��
	UM2052_write_byte(UM2052_BANK0_RX_PW_P0, 32);  // �������ݰ����ȣ�����Ƕ����Ļ���ֻ���շ����ó��ȵ����ݰ����䳤�Ļ�1~32�ֽڶ�����
	UM2052_write_byte(UM2052_BANK0_RF_CH, 0);
	UM2052_write_byte(UM2052_BANK0_EN_RXADDR, 0x0b); // 0x03:scramble_en = 0; 0x0b: scramble_en = 1 �׻���־
	UM2052_write_byte(UM2052_BANK0_RF_SETUP, 0x47);
	UM2052_write_byte(UM2052_BANK0_DYNPD, 0x07);
	
	UM2052_Clear_All_Irq();
	UM2052_Flush_Tx();	// ��TxFIFO
	UM2052_Flush_Rx();  // ��RxFIFO
	UM2052_CE_High();
}
// �������״̬
void Radio_GoRx(void)
{
	UM2052_CE_Low();
	UM2052_ModeSwitch(UM2052_PRX_Mode);  // �л���Rx  //UM2052_write_byte(UM2052_BANK0_CONFIG, 0xfb); 
	UM2052_CE_High();
}

// ��Ƶ��������
void Radio_Send(uint8_t *pData, uint8_t tLen)
{
	UM2052_CE_Low();
	UM2052_ModeSwitch(UM2052_PTX_Mode);  // �л���Tx
	
	UM2052_SendPack(UM2052_W_TX_PAYLOAD, pData, tLen);
	// ���Ͷˣ�ֻ������������Ҫ���͵�ʱ��Ÿ�CE�źţ�����ʱ��CE�������͵�--�����Ҫ�л������յĻ�����ô�ڽ���״̬��CEҪһֱΪ��
//	UM2052_Operation(UM2052_REUSE_TX_PL);
	UM2052_CE_High();  //ce pulse 20us
	delay_us(1000);
	UM2052_CE_Low();
	delay_us(1000);
	
	UM2052_Flush_Tx();
	UM2052_Clear_All_Irq();
	Radio24G_Config();
	Radio_GoRx();
}

// ��ѯ��������
uint8_t Radio_Recv(uint8_t *pData)
{
	unsigned char status = 0x00;
	unsigned char len;
	
//  delay_us(100);  // ��ʱ100us����Ƶ����ȡ״̬�Ĵ���
  status = UM2052_read_byte(UM2052_BANK0_STATUS);   // ��ȡ״̬�Ĵ��������Ƿ����յ�����
	
  if((UM2052_STATUS_RX_DR & status))  // ����յ�����
  {
//    len = UM2052_ReceivePack(pData);  // ��ȡFIFO��������ݵĳ���
		{
			unsigned char sta;
			unsigned char fifo_sta;
//			unsigned char len;

			sta = UM2052_read_byte(UM2052_BANK0_STATUS);

			if(UM2052_STATUS_RX_DR & sta)
			{
				do
				{
					len = UM2052_read_byte(UM2052_R_RX_PL_WID);
					
					if(len <= UM2052_FIFO_MAX_PACK_SIZE)
					{
						UM2052_read_buffer(UM2052_R_RX_PAYLOAD, pData, len);
					}
					else
					{
						UM2052_Flush_Rx();
					}
					
					fifo_sta = UM2052_read_byte(UM2052_BANK0_FIFO_STATUS);
					WDT_Clear();
				}while(!(fifo_sta & UM2052_FIFO_STA_RX_EMPTY));/*not empty continue read out*/ 
				
				UM2052_write_byte(UM2052_BANK0_STATUS, sta);/*clear irq*/
				UM2052_Clear_All_Irq();
				UM2052_Flush_Tx();
				UM2052_Flush_Rx();
//				return len;
			}

			if(sta & (UM2052_STATUS_RX_DR | UM2052_STATUS_TX_DS | UM2052_STATUS_MAX_RT))
			{
				UM2052_write_byte(UM2052_BANK0_STATUS, sta);/*clear irq*/
			}
		}
    // ���յ����ݲ���ȡFIFO֮������������������Ĳ���ҪCE����֮�����
    UM2052_CE_Low();  // CE����
    UM2052_Flush_Rx();  // ��RX FIFO
    UM2052_Clear_All_Irq();  // ��״̬�Ĵ�����־
    UM2052_CE_High();  // ִ����֮��CEҪ���ߵȴ����ݵĵ������������״̬��
		return len;
	}
  else
	{
		return 0;
	}
}

//// �ز����Ժ���
//void send_carrier_test(unsigned char ch)
//{
//	UM2052_CE_Low();
//	
//  printf("send carrier freq = 24%02d\r\n", ch);
//	UM2052_write_byte(UM2052_BANK0_CONFIG, 0x02);
//	UM2052_write_byte(UM2052_BANK0_RF_CH, ch); // �����ŵ�
//	UM2052_write_byte(UM2052_BANK0_RF_SETUP, 0xe7); // ���ʺ��ز�ͬʱ����
//	UM2052_CE_High(); // CEҪ���߲��ܳ��ز�
//	//while(1);
//}

// ��ӡUM2052���мĴ��������������Ե�ʱ�����ʹ�ã���Ʒ�ϲ���Ҫ��ֲ���
//void UM2052_Dump_RF_Register(void)
//{
//  unsigned char  reg_value;
//  unsigned char  temp[6];
//  signed char i;

//	UM2052_Operation(UM2052_CMD_CE_LOW);
//  
//  UM2052_Bank_Switch(UM2052_Bank0);
//    
//  UM2052_read_buffer(UM2052_BANK0_CONFIG, &reg_value, 1);
//  printf("\r\n\r\n\r\nUM2052_BANK0_CONFIG: %02x\r\n", reg_value);  
//  

//  UM2052_read_buffer(UM2052_BANK0_EN_AA, &reg_value, 1);
//  printf("UM2052_BANK0_EN_AA: %02x\r\n", reg_value); 

//  UM2052_read_buffer(UM2052_BANK0_EN_RXADDR, &reg_value, 1);
//  printf("UM2052_BANK0_EN_RXADDR: %02x\r\n", reg_value);  
//  

//  UM2052_read_buffer(UM2052_BANK0_PMU_CTL, &reg_value, 1);
//  printf("UM2052_BANK0_PMU_CTL: %02x\r\n", reg_value); 
//  
//  UM2052_read_buffer(UM2052_BANK0_SETUP_RETR, &reg_value, 1);
//  printf("UM2052_BANK0_SETUP_RETR: %02x\r\n", reg_value);	
//	
//  
//  UM2052_read_buffer(UM2052_BANK0_RF_CH, &reg_value, 1);
//  printf("UM2052_BANK0_RF_CH: %02x\r\n", reg_value); 
//  
//  UM2052_read_buffer(UM2052_BANK0_RF_SETUP, &reg_value, 1);
//  printf("UM2052_BANK0_RF_SETUP: %02x\r\n", reg_value); 

//  UM2052_read_buffer(UM2052_BANK0_STATUS, &reg_value, 1);
//  printf("UM2052_BANK0_STATUS: %02x\r\n", reg_value); 
//	
//  UM2052_read_buffer(UM2052_BANK0_RX_ADDR_P0, temp, 6);
//  printf("UM2052_BANK0_RX_ADDR_P0: "); 
//  for(i=5;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");
//  
//  UM2052_read_buffer(UM2052_BANK0_RX_ADDR_P1, &reg_value, 1);
//  printf("UM2052_BANK0_RX_ADDR_P1: %02x\r\n", reg_value); 
//  
//  UM2052_read_buffer(UM2052_BANK0_RX_ADDR_P2, &reg_value, 1);
//  printf("UM2052_BANK0_RX_ADDR_P2: %02x\r\n", reg_value); 

//  UM2052_read_buffer(UM2052_BANK0_TX_ADDR, temp, 6);
//  printf("UM2052_BANK0_TX_ADDR: "); 
//  for(i=5;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");
//	
//  UM2052_read_buffer(UM2052_BANK0_RX_PW_P0, &reg_value, 1);
//  printf("UM2052_BANK0_RX_PW_P0: %02x\r\n", reg_value); 
//  
//  UM2052_read_buffer(UM2052_BANK0_RX_PW_P1, &reg_value, 1);
//  printf("UM2052_BANK0_RX_PW_P1: %02x\r\n", reg_value);	
//	
//  
//  UM2052_read_buffer(UM2052_BANK0_RX_PW_P2, &reg_value, 1);
//  printf("UM2052_BANK0_RX_PW_P2: %02x\r\n", reg_value); 

// UM2052_read_buffer(UM2052_BANK0_FIFO_STATUS, &reg_value, 1);
//  printf("UM2052_BANK0_FIFO_STATUS: %02x\r\n", reg_value);  
//  
//  UM2052_read_buffer(UM2052_BANK0_DYNPD, &reg_value, 1);
//  printf("UM2052_BANK0_DYNPD: %02x\r\n", reg_value); 
//  
//  UM2052_read_buffer(UM2052_BANK0_FEATURE, &reg_value, 1);
//  printf("UM2052_BANK0_FEATURE: %02x\r\n", reg_value); 


//  UM2052_read_buffer(UM2052_BANK0_SETUP_VALUE, temp, 3);
//  printf("UM2052_BANK0_SETUP_VALUE: ");
//  for(i=2;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");
//  
//  
//  UM2052_read_buffer(UM2052_BANK0_PRE_GURD, temp, 3);
//  printf("UM2052_BANK0_PRE_GURD: ");  
//  for(i=2;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n\r\n");
//  
//  UM2052_Bank_Switch(UM2052_Bank1);

//  UM2052_read_buffer(UM2052_BANK1_CHIP_ID, temp, 2);
//  printf("UM2052_BANK1_CHIP_ID:");
//  for(i=1;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 
//  
//  UM2052_read_buffer(UM2052_BANK1_PLL_CTL0, temp, 4);
//  printf("UM2052_BANK1_PLL_CTL0:");
//  for(i=3;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");  

//  UM2052_read_buffer(UM2052_BANK1_PLL_CTL1, temp, 3);
//  printf("UM2052_BANK1_PLL_CTL1:");
//  for(i=2;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");

//  UM2052_read_buffer(UM2052_BANK1_CAL_CTL, temp, 4);
//  printf("UM2052_BANK1_CAL_CTL:");
//  for(i=3;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");

//  UM2052_read_buffer(UM2052_BANK1_STATUS, &reg_value, 1);
//  printf("UM2052_BANK1_STATUS:%02x\r\n", reg_value);   

//  UM2052_read_buffer(UM2052_BANK1_STATE, &reg_value, 2);
//  printf("UM2052_BANK1_STATE:");
//  for(i=1;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 

//  UM2052_read_buffer(UM2052_BANK1_CHAN, &reg_value, 4);
//  printf("UM2052_BANK1_CHAN:");
//  for(i=3;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");    


//  UM2052_read_buffer(UM2052_BANK1_FDEV, &reg_value, 1);
//  printf("UM2052_BANK1_FDEV:%02x\r\n", reg_value);  
//	
//  UM2052_read_buffer(UM2052_BANK1_DAC_RANGE, &reg_value, 1);
//  printf("UM2052_BANK1_DAC_RANGE:%02x\r\n", reg_value);  

//  UM2052_read_buffer(UM2052_BANK1_CTUNING, temp, 2);
//  printf("UM2052_BANK1_CTUNING:");
//  for(i=1;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 
//  
//  UM2052_read_buffer(UM2052_BANK1_FTUNING, temp, 2);
//  printf("UM2052_BANK1_FTUNING:");
//  for(i=1;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 
//	
//  UM2052_read_buffer(UM2052_BANK1_RX_CTRL, temp, 2);
//  printf("UM2052_BANK1_RX_CTRL:");
//  for(i=2;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");    

//  UM2052_read_buffer(UM2052_BANK1_FAGC_CTRL_1, temp, 4);
//  printf("UM2052_BANK1_FAGC_CTRL_1:");
//  for(i=3;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 
//	
//  UM2052_read_buffer(UM2052_BANK1_DOC_DACI, &reg_value, 1);
//  printf("UM2052_BANK1_DOC_DACI:%02x\r\n", reg_value);  
//	
//  UM2052_read_buffer(UM2052_BANK1_DOC_DACQ, &reg_value, 1);
//  printf("UM2052_BANK1_DOC_DACQ:%02x\r\n", reg_value);  

//  UM2052_read_buffer(UM2052_BANK1_AGC_CTRL, temp, 4);
//  printf("UM2052_BANK1_AGC_CTRL:");
//  for(i=3;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 
//	
//  UM2052_read_buffer(UM2052_BANK1_AGC_GAIN, temp, 4);
//  printf("UM2052_BANK1_AGC_GAIN:");
//  for(i=3;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 

//  UM2052_read_buffer(UM2052_BANK1_RF_IVGEN, temp, 3);
//  printf("UM2052_BANK1_RF_IVGEN:");
//  for(i=2;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n"); 
//	
//  UM2052_read_buffer(UM2052_BANK1_TEST_PKDET, temp, 3);
//  printf("UM2052_BANK1_TEST_PKDET:");
//  for(i=2;i>=0;i--)
//    printf("%02x " , temp[i]);
//  printf("\r\n");

//  UM2052_Bank_Switch(UM2052_Bank0);
//}
