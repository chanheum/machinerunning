
#ifndef _APP_Show_Display_H_
#define _APP_Show_Display_H_

#include "config.h"

#define Wireless_Power_OF	0x00
#define Wireless_Power_ON	0x01

#define Wireless_State_Wait		0x00
#define Wireless_State_Pause	0x02
#define Wireless_State_RUN		0x01

#define Wireless_Mode_AT1	1
#define Wireless_Mode_AT2	2
#define Wireless_Mode_AT3	3
#define Wireless_Mode_AT4	4
#define Wireless_Mode_AT5	5
#define Wireless_Mode_MT1	6
#define Wireless_Mode_MT2	7
#define Wireless_Mode_MT3	8
#define Wireless_Mode_MT4	9
#define Wireless_Mode_MT5	0X0A
#define Wireless_Mode_MT6	0X0B

/*
typedef struct
{
	uint8_t 	Head;		//
	uint8_t 	Ver;		//
	uint8_t 	Data0_Power;
	uint8_t 	Data1_State;
	uint8_t 	Data2_Mode;
	uint8_t 	Data3_Strength;
	uint8_t 	Data4_Time;
	uint8_t 	Data5_Heat;
	uint8_t 	Data6_Volume;
	uint8_t 	Data7_Ball_state;
	uint8_t 	Data8_Error;
	uint8_t 	SUM;
	uint8_t 	Tial;
} Wireless_RX_struct;
extern Wireless_RX_struct 	Wireless_RX;
*/
typedef struct
{
	uint8_t 	Head;		//
	uint8_t 	Data0;
	uint8_t 	Data1;
	uint8_t 	Data2;
    uint8_t 	Data3;
    uint8_t     Paring1;
    uint8_t     Paring2;
	uint8_t 	SUM;
	uint8_t 	Tial;
} Wireless_RX_struct;
extern Wireless_RX_struct 	Wireless_RX;



//typedef enum
//{
//	Display_NULL = 0,
//	Display_ON,
//	Display_OFF,
//	Display_PAUSE,
//	Display_AT,
//	Display_MT,
//	Display_Ball_UP,
//	Display_Ball_DW,
//	Display_Strenth,
//	Display_Time,
//	Display_addTime,
//	Display_HEAT,
//	Display_NONE,

//}Display_ENUM;

void Show_Display_init(void);
//void Display_Type_Set(Display_ENUM x);
//void LED_Display_DUTY_SET(u8 dat);		//��ʾ�������� 0-7
void Show_Display_DATA_SET(u8 *np, u8 num);	//��������
void Show_Display_Drive(void); // //100msʱ������һ��

#endif

