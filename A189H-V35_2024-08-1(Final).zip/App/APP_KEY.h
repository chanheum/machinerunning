
#ifndef __APP_KEY_H_
#define __APP_KEY_H_

#include "config.h"

//#define	KEY_Null 	 0X000000
#define	KEY_Power 	 0X010000
#define	KEY_Pause 	 0X020000
#define	KEY_AT 		 0X040000
#define	KEY_MT 		 0X080000
#define	KEY_Str 	 0X100000
#define	KEY_Heat 	 0X200000
#define	KEY_Time 	 0X400000
#define	KEY_Vol 	 0X800000
#define	KEY_LegUP 	 0X000100
#define	KEY_LegDW 	 0X000400
#define	KEY_BackUP 	 0X000800
#define	KEY_BackDW 	 0X002000
#define	KEY_Zero 	 0X000002
#define	KEY_BallUP 	 0X000010
#define	KEY_MSGBall  0X000020
#define	KEY_BallDW 	 0X000040
// remote -> main
#define KEY_ParingSet 0X240000 // Auto + Heat
#define KEY_ParingClr 0X280000 // Manual + Heat
#define KEY_Skip 0XC00000 // Time + Vol
#define KEY_My   0X300000 // Str + Heat
#define KEY_Test 0X420000 // Pause + Time
#define KEY_Version 0X820000 // Pause + Vol
//#define KEY_Etc1 0X120000
//#define KEY_Etc2 0X220000

typedef union {
    u32 Data;
    u8 Value[4]; // Key.Value[0] ��8λ   Key.Value[1] ��8λ
}Key_union;
extern Key_union Cur_Key;
extern Key_union Pre_Key;
	
#define KEY0 P24
#define KEY1 P25
#define KEY2 P26
#define KEY3 P27
#define KEY4 P37

#define KEY_D0 P33
#define KEY_D1 P11
#define KEY_D2 P32
#define KEY_D3 P10
//#define KEY_D4 P10

#define     EE_ADDRESS  0x0000  //�����EEPROM��ʼ��ַ
#define     EE_ADDRESS_C_1 0x0002



void KeyTask(void); // 10ms
void MCU_SLEEP_HANDLE(void); // 10ms	
u16 ADCRead(void); 
void LowpowerCheck(void); 
void    Display(void);
void    DisableEEPROM(void);
void    EEPROM_read_n(u16 EE_address,u8 *DataAddress,u16 number);
void    EEPROM_write_n(u16 EE_address,u8 *DataAddress,u16 number);
void    EEPROM_SectorErase(u16 EE_address);
#endif

