#ifndef __BSP_UM2052_H__
#define __BSP_UM2052_H__


#define rx_lenth					10

//-------------RF command---------------------
#define UM2052_R_REGISTER				  0x00 // Define read command to register
#define UM2052_W_REGISTER				  0x20 // Define write command to register
#define UM2052_R_RX_PAYLOAD				0x61 // Define RX payload register address
#define UM2052_W_TX_PAYLOAD				0xA0 // Define TX payload register address
#define UM2052_FLUSH_TX					  0xE1 // Define flush TX register command
#define UM2052_FLUSH_RX					  0xE2 // Define flush RX register command
#define UM2052_REUSE_TX_PL				0xE3 // Define reuse TX payload register command
#define UM2052_ACTIVATE					  0x50 // Define ACTIVATE features register command
#define UM2052_R_RX_PL_WID				0x60 // Define read RX payload width register command
#define UM2052_W_ACK_PAYLOAD			0xA8 // Define write ACK payload register command
#define UM2052_W_TX_PAYLOAD_NOACK	0xB0 // Define disable TX ACK for one time register command
#define UM2052_NOP						    0xFF // Define No Operation, might be used to read status register
#define UM2052_READ_STATUS				0xFF

#define UM2052_ACTIVATE_DATA			0x53

#define UM2052_CMD_CE_HIGH				0xD5
#define UM2052_CMD_CE_LOW				  0xD6

///  UM2052 Bank0 Register Addr
/**************************************************/               
#define UM2052_BANK0_CONFIG             0x00 // 'Config' register address
#define UM2052_BANK0_EN_AA              0x01 // 'Enable Auto Acknowledgment' register address
#define UM2052_BANK0_EN_RXADDR          0x02 // 'Enabled RX addresses' register address
#define UM2052_BANK0_PMU_CTL            0x03 // 'Setup address width' register address
#define UM2052_BANK0_SETUP_RETR         0x04 // 'Setup Auto. Retrans' register address
#define UM2052_BANK0_RF_CH          	  0x05 // 'UM2052 channel' register address
#define UM2052_BANK0_RF_SETUP       	  0x06 // 'UM2052 setup' register address
#define UM2052_BANK0_STATUS             0x07 // 'Status' register address                  
#define UM2052_BANK0_RX_ADDR_P0         0x0A // 'RX address pipe0' register address
#define UM2052_BANK0_ACCESS_ADDR        0x0A
#define UM2052_BANK0_RX_ADDR_P1         0x0B // 'RX address pipe1' register address
#define UM2052_BANK0_BLE_TIM_CNT		    0x0B 
#define UM2052_BANK0_RX_ADDR_P2         0x0C // 'RX address pipe2' register address
#define UM2052_BANK0_BLE_CTL            0x0C // 'BLE Ctrol' register address
#define UM2052_BANK0_TX_ADDR            0x10 // 'TX address' register address
#define UM2052_BANK0_TX_ADVA_ADDR       0x10
#define UM2052_BANK0_RX_PW_P0           0x11 // 'RX payload width, pipe0' register address
#define UM2052_BANK0_TX_HEADER			    0x11 // 'BLE TX Header' register address
#define UM2052_BANK0_RX_PW_P1           0x12 // 'RX payload width, pipe1' register address
#define UM2052_BANK0_CRC_INIT           0x12
#define UM2052_BANK0_RX_PW_P2           0x13 // 'RX payload width, pipe2' register address
#define UM2052_BANK0_STATUS_EXT         0x16
#define UM2052_BANK0_FIFO_STATUS        0x17 // 'FIFO Status Register' register address
#define UM2052_BANK0_CONFIG_EXT         0x18
#define UM2052_BANK0_DYNPD              0x1C // 'Enable dynamic payload length' register address
#define UM2052_BANK0_FEATURE            0x1D // 'Feature' register address
#define UM2052_BANK0_SETUP_VALUE        0x1E
#define UM2052_BANK0_PRE_GURD           0x1F

///   UM2052 Bank1 register
#define UM2052_BANK1_CHIP_ID            0x00
#define UM2052_BANK1_PLL_CTL0           0x01
#define UM2052_BANK1_PLL_CTL1           0x02
#define UM2052_BANK1_CAL_CTL            0x03
#define UM2052_BANK1_STATUS             0x07
#define UM2052_BANK1_STATE              0x08
#define UM2052_BANK1_CHAN               0x09
#define UM2052_BANK1_FDEV               0x0C
#define UM2052_BANK1_DAC_RANGE          0x0D
#define UM2052_BANK1_CTUNING            0x0F
#define UM2052_BANK1_FTUNING            0x10
#define UM2052_BANK1_RX_CTRL            0x11
#define UM2052_BANK1_FAGC_CTRL_1        0x13
#define UM2052_BANK1_DOC_DACI           0x1A
#define UM2052_BANK1_DOC_DACQ           0x1B
#define UM2052_BANK1_AGC_CTRL           0x1C
#define UM2052_BANK1_AGC_GAIN           0x1D
#define UM2052_BANK1_RF_IVGEN       	  0x1E
#define UM2052_BANK1_TEST_PKDET         0x1F

#define UM2052_FIFO_MAX_PACK_SIZE		    0x20
#define UM2052_FIFO_STA_RX_FULL			    0x02
#define UM2052_FIFO_STA_RX_EMPTY		    0x01

#define UM2052_STATUS_RX_DR				      0x40
#define UM2052_STATUS_TX_DS				      0x20
#define UM2052_STATUS_MAX_RT			      0x10
#define UM2052_STATUS_TX_FULL			      0x01

#define BIT0                            0x01
#define BIT1                            0x02
#define BIT2                            0x04
#define BIT3                            0x08
#define BIT4                            0x10
#define BIT5                            0x20
#define BIT6                            0x40
#define BIT7                            0x80

//config register bit define
#define PRIM_RX                         BIT0
#define PWR_UP                          BIT1
#define CE_REG                          BIT2
#define EN_CRC                          BIT3
#define MASK_MAX_RT                     BIT4
#define MASK_TX_DS                      BIT5
#define MASK_RX_DR                      BIT6
#define GUARD_EN                        BIT7

//pmu_ctl register bit define
#define UM2052_PWRDN_MASK				  0x03   
#define UM2052_PWRDN_WORK				  0x00 
#define UM2052_PWRDN_SDAND_BY			0x02 
#define UM2052_PWRDN_SLEEP				0x01 

#define DLDO_ENB_REG                    BIT3
#define DLDO_ENB_MN                     BIT4

//DYNPD register bit define
#define SPI4_EN                         BIT3
#define XN297_EN                        BIT4
#define BYPASS_IO                       BIT5
#define REG_OUTPUT_EN                   BIT6
#define REG_OUTPUT                      BIT7

//FEATURE register bit define
#define EN_DYN_ACK                      BIT0
#define EN_ACK_PAY                      BIT1
#define EN_DPL                          BIT2
#define VCO_AMP_TX_MUX                  BIT3
#define BP_GAU                          BIT4
#define SOFT_RST                        BIT5
#define BLE_EN                          BIT6
#define LONG_PACKET_EN                  BIT7

//STATUS_EXT register bit define
#define LENERR                          BIT2
#define CRCERR                          BIT3
#define TX_AEMPTY                       BIT0
#define RX_AFULL                        BIT1
#define LENERR                          BIT2
#define CRCERR                          BIT3
#define SYNC_DS													BIT4
#define TX_DS            								BIT5
#define RX_DR            								BIT6
#define EVT_DS           								BIT7

typedef enum {
	UM2052_Bank0 = 0,
	UM2052_Bank1 = 0x80
}UM2052_Bank_TypeDef;

typedef enum {
	UM2052_PRX_Mode = 0,
	UM2052_PTX_Mode,
	UM2052_Carrier_Mode
}UM2052_ModeTypeDef;

typedef enum {
	Rate_1M = 0,
	Rate_2M = 0x80
}UM2052_Rate_TypeDef;

typedef enum {
	Pwr_8db = 0,
	Pwr_5db,
	Pwr_4db,
	Pwr_0db,
	Pwr_n6db,
	Pwr_n12db,
	Pwr_n16db,
	Pwr_n43db,
}UM2052_Pwr_TypeDef;

// UM2052初始化函数
void UM2052_Init(void);
// UM2052 清标志
void UM2052_Clear_All_Irq(void);
// UM2052 清TX FIFO
void UM2052_Flush_Tx(void);
// UM2052 清RX FIFO
void UM2052_Flush_Rx(void);
// UM2052 CE 拉高
void UM2052_CE_High(void);
// UM2052 CE 拉低
void UM2052_CE_Low(void);
// UM2052 工作模式切换
void UM2052_ModeSwitch(UM2052_ModeTypeDef mod);
// UM2052 BANK 切换
void UM2052_Bank_Switch(UM2052_Bank_TypeDef bank);
// UM2052 切换速率
void UM2052_Change_Rate(UM2052_Rate_TypeDef rate);
// UM2052 切换信道
void UM2052_Change_CH(unsigned char chn);
// UM2052 切换功率
void UM2052_Change_Pwr(UM2052_Pwr_TypeDef pwr);
// UM2052 切换地址
void UM2052_Change_Addr(unsigned char *buf, unsigned char len);
// UM2052 发送数据包
void UM2052_SendPack(unsigned char cmd, unsigned char* buf, unsigned char len);
// UM2052 接收数据包
unsigned char UM2052_ReceivePack(unsigned char *buf);
// UM2052 读取接收数据包长度
unsigned char UM2052_read_payload_length(void);
// 
void UM2052_irq_config(void);

void UM2052_Enter_Sleep(void);  // RF进入睡眠的操作
void UM2052_Leave_Sleep(void);  // RF退出睡眠的操作

#endif
