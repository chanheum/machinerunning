
#include "APP_LED_Display.h"
extern u16 vcc;
extern u8 u8Backlight;
extern u8 u8Digit_1;
extern u8 u8Digit_2;
extern u8 u8Led_1;
extern u8 u8Led_2;
unsigned char code smgduan[] = {
    // ������ʾ
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F, // 9
    0x77, // A  10
    0x7C, // b  11
    0x39, // C  12
    0x5E, // d  13
    0x79, // E  14
    0x71, // F  15
    0x3D, // G  16
    0x76, // h  17
    0x04, // i  18
    0x0E, // J  19
    0x70, // K  20
    0x38, // L  21
    0x55, // m  22
    0x54, // n  23
    0x5C, // o  24
    0x73, // P  25
    0x67, // q  26
    0x50, // r  27
    0x6D, // S  28
    0x78, // t  29
    0x3E, // U  30
    0x1C, // v  31
    0x1D, // w  32
    0x76, // X  33
    0x72, // y  34
    0x49, // Z  35

    0x40, // -  		36
    0x80, // DP . 	37
    0x00, // null 	38
    0xff, // ALL  	39
    0x08, // _  		40
    0x01, // ``  	41
};

void LED_Display_init(void)
{

    P2 |= B0000_1111;
    P2_MODE_OUT_PP(B0000_1111); // ������ￄ1�7 λ�� ����

    P0 &= ~B0000_1111;
    P0_MODE_OUT_OD(B0000_1111); // ©����·

    P3 &= ~B0111_0000;
    P3_MODE_OUT_OD(B0111_0000); // ©����·

    COMEN  = B0000_1111;                    // COM0-COM4
    SEGENL = B0000_0000;                    // SEG0-SEG7
    SEGENH = B0111_1111;                    // SEG8-SEG15
    LEDCTRL |= B0001_0111;                  // B5 B4LEDMODE[1:0]��LED����ģʽ  LEDDUTY[2:0]��LED�Ҷȵ���
    LEDCKS = MAIN_Fosc / 160 / 8 / 4 / 100; // LED����Ƶ��100HZ

    LEDCTRL |= B1000_0000; // ʹ������LED ����
    //	HIGHPOWER_EN=0;					//ʹ��5v����
    // P20=0;
    // P21=0;
    // P22=0;
    // P23=0;

    // //�����õ�
    // P00=0;
    // P01=0;
    // P02=0;
    // P03=0;
    // P34=0;
    // P35=0;
    // P36=0;
    // COM0_DA_H = 0x00;
    // COM0_DA_H = 0x00;
    // COM0_DA_H = 0x00;
    // COM0_DA_H = 0x00;
}

void LED_Display_DUTY_SET(u8 dat) // ��ʾ�������� 0-7
{
    u8 buf;
    if (dat > 7) dat = 7;
    buf = 7 - dat;

    LEDCTRL &= ~B0000_0111;
    LEDCTRL |= buf;
}

void LED_Display_DATA_SET(u8 *np)
{
    np[0] &= ~B1000_0000;
    COM0_DA_H = np[0];
    //	TX1_write2buff(COM0_DC_H);

    np[1] &= ~B1000_0000;
    COM1_DA_H = np[1];
    //	TX1_write2buff(COM1_DC_H);

    np[2] &= ~B1000_0000;
    COM2_DA_H = np[2];
    //	TX1_write2buff(COM2_DC_H);

    //	if(np[3] & B1000_0000)	Back_LED = 0;
    //	else Back_LED = 1;

    //	TX1_write2buff(np[3] & B1000_0011);

    np[3] &= ~B1111_1100;
    COM3_DA_H = np[3];
    if (vcc <= 2650) {
        COM3_DA_H |= B0000_0100;
    }
    LED_Display_DUTY_SET(7);
}
