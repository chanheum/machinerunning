
#ifndef __APP_log_H_
#define __APP_log_H_

#include "config.h"

#define Com_Head 0xAA
#define Com_Tial 0X55

#define Com_CheckSum_Start 			0 	//У��ͼ��㿪ʼλ
#define Com_CheckSum_Stop 			6		//У��ͼ������λ
#define Com_CheckSum_data 			7		//У�������λ
#define Com_MAX_data 				7		//���λ��

#define Com_RX_read COM1.RX_read
#define Com_RX_write COM1.RX_Cnt
#define Com_Get_data() RX1_Read()

typedef struct
{
    u8 Head;
    u8 Tial;
    u8 DUTY;
    u8 DATA[4];
    u8 sum;
} COM_RX_Struct;
extern COM_RX_Struct 	COM_RX_User;

void log_UART_init(void);
void log_print(void);
void COM_log_RX(void);

#endif

