
#ifndef __APP_LED_Display_H_
#define __APP_LED_Display_H_

#include "config.h"

#define Back_LED	P16
#define HIGHPOWER_EN	    P54
enum {  //�����ַ���ʾ		��дA ASCII��0x41�� 'A'-0X41+10 = 'A'-0X31
    SMG_G=16,
    SMG_h=17,
    SMG_i=18,
    SMG_J=19,
    SMG_K=20,
    SMG_L=21,
    SMG_m=22,
    SMG_n=23,
    SMG_o=24,
    SMG_P=25,
    SMG_q=26,
    SMG_r=27,
    SMG_S=28,
    SMG_t=29,
    SMG_U=30,
    SMG_v=31,
    SMG_w=32,
    SMG_X=33,
    SMG_Y=34,
    SMG_Z=35,
	
	SMG_=36, 	// -  		36
	SMG_DP=37, 	// DP . 	37
	SMG_NULL=38,//null 	38
	SMG_ALL=39,	//ALL  	39
};
extern unsigned char code smgduan[];

void LED_Display_init(void);
void LED_Display_DUTY_SET(u8 dat);		//��ʾ�������� 0-7
void LED_Display_DATA_SET(u8 *np);	//��ʾ�������� 

#endif

