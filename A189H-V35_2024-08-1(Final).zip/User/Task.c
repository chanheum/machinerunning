
#include	"Task.h"
#include	"app.h"
#include "Coway_display.h"
//========================================================================
//                               ���ر�������
//========================================================================

static TASK_COMPONENTS Task_Comps[]=
{
//״̬  ����  ����  ����
	{0, 1, 1, COM_log_RX},          /* task 8 Period�� 100ms */
	{1, 1000, 1000, LowpowerCheck }, // 100ms
	{0, 10, 10, RF_IAP_Read_Irq_Rx},  // 30ms
	{0, 100, 100, Show_Display_Drive},           /* task 6 Period�� 1ms */
  {0, 100, 100, CowayProcess }, // 100ms			
	{0, 10, 10, KeyTask},          /* task 8 Period�� 100ms */
	{0, 500, 500, Sample_Lamp},         /* task 1 Period�� 250ms */
//	{0, 1000, 1000, log_print},          /* task 8 Period�� 100ms */
	{0, 1000, 1000, Sample_WDT},          /* task 8 Period�� 100ms */
	/* Add new task here */
};

u8 Tasks_Max = sizeof(Task_Comps)/sizeof(Task_Comps[0]);

//========================================================================
// ����: Task_Handler_Callback
// ����: �����ǻص�����.
// ����: None.
// ����: None.
// �汾: V1.0, 2012-10-22
//========================================================================
void Task_Marks_Handler_Callback(void)
{
	u8 i;
	for(i=0; i<Tasks_Max; i++)
	{
		if(Task_Comps[i].TIMCount)    /* If the time is not 0 */
		{
			Task_Comps[i].TIMCount--;  /* Time counter decrement */
			if(Task_Comps[i].TIMCount == 0)  /* If time arrives */
			{
				/*Resume the timer value and try again */
				Task_Comps[i].TIMCount = Task_Comps[i].TRITime;  
				Task_Comps[i].Run = 1;    /* The task can be run */
			}
		}
	}
}

//========================================================================
// ����: Task_Pro_Handler_Callback
// ����: �������ص�����.
// ����: None.
// ����: None.
// �汾: V1.0, 2012-10-22
//========================================================================
void Task_Pro_Handler_Callback(void)
{
	u8 i;
	for(i=0; i<Tasks_Max; i++)
	{
		if(Task_Comps[i].Run) /* If task can be run */
		{
			Task_Comps[i].Run = 0;    /* Flag clear 0 */
			Task_Comps[i].TaskHook();  /* Run task */
		}
	}
}


