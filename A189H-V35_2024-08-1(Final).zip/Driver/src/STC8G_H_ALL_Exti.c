#include	"STC8G_H_ALL_Exti.h"
#include	"STC8G_H_GPIO.h"

u8	ALL_Ext_Init(ALL_Ext_InitDefine *ALL_Ext_Pra)
{
	if(ALL_Ext_Pra->GPIO_Px >  GPIO_P7)	return FAIL;	//�ղ���
	if(ALL_Ext_Pra->GPIO_Pin_x >  GPIO_Pin_All)	return FAIL;	//�ղ���
	
	if(ALL_Ext_Pra->GPIO_Px == GPIO_P0)
	{
		P0INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P0IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P0IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P0IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P0IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P0IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P0IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P0IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P0IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P0WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P0WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	else if(ALL_Ext_Pra->GPIO_Px == GPIO_P1)
	{
		P1INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P1IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P1IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P1IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P1IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P1IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P1IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P1IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P1IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P1WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P1WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	else if(ALL_Ext_Pra->GPIO_Px == GPIO_P2)
	{
		P1INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P2IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P2IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P2IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P2IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P2IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P2IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P2IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P2IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P2WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P2WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	else if(ALL_Ext_Pra->GPIO_Px == GPIO_P3)
	{
		P1INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P3IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P3IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P3IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P3IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P3IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P3IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P3IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P3IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P3WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P3WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	else if(ALL_Ext_Pra->GPIO_Px == GPIO_P4)
	{
		P1INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P4IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P4IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P4IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P4IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P4IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P4IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P4IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P4IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P4WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P4WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	else if(ALL_Ext_Pra->GPIO_Px == GPIO_P5)
	{
		P1INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P5IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P5IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P5IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P5IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P5IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P5IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P5IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P5IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P5WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P5WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	else if(ALL_Ext_Pra->GPIO_Px == GPIO_P6)
	{
		P1INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P6IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P6IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P6IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P6IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P6IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P6IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P6IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P6IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P6WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P6WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	else if(ALL_Ext_Pra->GPIO_Px == GPIO_P7)
	{
		P1INTE = ALL_Ext_Pra->GPIO_Pin_x;
		//�ж�ģʽ
		if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Fall)	//�½����ж�
		{
			P7IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P7IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Rise)	//�������ж�
		{
			P7IM1 &= ~ALL_Ext_Pra->GPIO_Pin_x;
			P7IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_Low)	//�͵�ƽ�ж�
		{
			P7IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P7IM0 &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		else if(ALL_Ext_Pra->EXT_MODE_x == EXT_MODE_High)	//�ߵ�ƽ�ж�
		{
			P7IM1 |= ALL_Ext_Pra->GPIO_Pin_x;
			P7IM0 |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		
		//�жϵ��绽��ʹ��
		if(ALL_Ext_Pra->PnxWKUE_EN == ENABLE)	//�½����ж�
		{
			P7WKUE |= ALL_Ext_Pra->GPIO_Pin_x;
		}
		else
		{
			P7WKUE &= ~ALL_Ext_Pra->GPIO_Pin_x;
		}
		return SUCCESS;		//�ɹ�
	}
	return FAIL;	//ʧ��
}
u8 NVIC_ALL_Ext_Init(u8 EXT_Priority_x,u8 GPIO_ALL_Px)
{
    if (EXT_Priority_x > Priority_3) return FAIL;
	//�ж����ȼ�
	if(EXT_Priority_x == Priority_0)	//Px ���ж����ȼ�Ϊ 0 ������ͼ���
	{
		PINIPL &= ~GPIO_ALL_Px;
		PINIPH &= ~GPIO_ALL_Px;
	}
	else if(EXT_Priority_x == Priority_1)	//Px ���ж����ȼ�Ϊ 1 �����ϵͼ���
	{
		PINIPL &= ~GPIO_ALL_Px;
		PINIPH |= GPIO_ALL_Px;
	}
	else if(EXT_Priority_x == Priority_2)	//Px ���ж����ȼ�Ϊ 2 �����ϸ߼���
	{
		PINIPL |= GPIO_ALL_Px;
		PINIPH &= ~GPIO_ALL_Px;
	}
	else if(EXT_Priority_x == Priority_3)	//Px ���ж����ȼ�Ϊ 3 ������߼���
	{
		PINIPL |= GPIO_ALL_Px;
		PINIPH |= GPIO_ALL_Px;
	}
    return SUCCESS;
}

