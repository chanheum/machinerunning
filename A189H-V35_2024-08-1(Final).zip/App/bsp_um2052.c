/***********************************************************************
 * Copyright (c)  2017 - 2020, Unicmicro Co.,Ltd .
 * All rights reserved.
 * Filename    : mbsp_UM2052.c
 * Description : bsp_UM2052.c
 * Author(s)   : Dan
 * version     : V1.0
 * Modify date : 2019-02-21
 ***********************************************************************/
#include	"APP.h"

/* UM2052 初始化函数
第一版的模块，只做测试用，初始化的内容还有点多
改第二版之后，有些值会作为默认值，初始化内容就会少很多
*/
void UM2052_Init(void)
{
	unsigned char temp[5];
	//UM2052_SPI_Init();
	
	UM2052_write_byte(UM2052_BANK0_FEATURE, SOFT_RST); // soft_reset		0X20   BIT5   0X1D+0X20 = 0X3D		0X20

//#if (UM2052_SPI_NWIRE == SPI_4_WIRE) 
	// 默认是3线SPI的，如果要使用4线SPI，则上电之后要设置一下
//	UM2052_write_byte(UM2052_BANK0_DYNPD, 0x08);
//#else
	UM2052_write_byte(UM2052_BANK0_DYNPD, 0x00);			//0X20+0X1C = 0X3C  ,0X00
//#endif

	UM2052_CE_Low();	
	UM2052_write_byte(UM2052_BANK0_CONFIG, 0x8b); // power up 芯片上电
	delay_ms(3); // Delay1ms(3); // wait 3 ms
	UM2052_write_byte(UM2052_BANK0_PMU_CTL, 0xac); // UM2052_PWRDWN = 00是芯片处于工作模式
	delay_ms(2); // Delay1ms(2);
    
	UM2052_write_byte(UM2052_BANK0_FEATURE, 0x10); // VCO_AMP_TX_MUX = b'0, A2 don't need config this bit

	UM2052_Bank_Switch(UM2052_Bank1);
	
	UM2052_write_byte(UM2052_BANK1_TEST_PKDET, 0x20); // pll_vdiv2_sel = 01, A2 don't need config this bit
    
	temp[2] = 0x05;
	temp[1] = 0xa0;
	temp[0] = 0x01;
	UM2052_wr_buffer(UM2052_BANK1_FAGC_CTRL_1, temp, 3);
    
	temp[1] = 0xb2;
	temp[0] = 0xcf;  
	UM2052_wr_buffer(UM2052_BANK1_AGC_CTRL, temp, 2);
	
	UM2052_Bank_Switch(UM2052_Bank0);

	UM2052_CE_High();
//	delay_us(100);   // Delay10us(10);
	delay_ms(25); // Delay1ms(2);
	UM2052_CE_Low(); // 一定要注意，校准的时候CE是低的

//	while((UM2052_read_byte(UM2052_BANK0_RF_SETUP) & 0x20) == 0x00);  // wait cal done
	
	UM2052_write_byte(UM2052_BANK0_RF_SETUP, 0x40);  // cal_en = 0 清除校准位使能

  UM2052_Bank_Switch(UM2052_Bank1);
	temp[2] = 0x75;  // bp_dac =1 bp_rc = 1
	temp[1] = 0x98;  // bp_vco_amp = 1 bp_vco_ldo=1
	temp[0] = 0x20;
	UM2052_wr_buffer(UM2052_BANK1_CAL_CTL, temp, 3);
	
	temp[2] = 0xFF;  // bp_dac =1 bp_rc = 1
	temp[1] = 0xFF;  // bp_vco_amp = 1 bp_vco_ldo=1
	temp[0] = 0xFF;
	UM2052_wr_buffer(UM2052_BANK1_PLL_CTL1, temp, 3);
	
  UM2052_Bank_Switch(UM2052_Bank0);	
	temp[0] = 0x46;
	temp[1] = 0x0b;
	temp[2] = 0xaf;
	temp[3] = 0x43;
	temp[4] = 0x98;	
	UM2052_wr_buffer(UM2052_BANK0_RX_ADDR_P0, temp, 5); // set RX address
	UM2052_wr_buffer(UM2052_BANK0_TX_ADDR, temp, 5);  //set TX address
  
	UM2052_Clear_All_Irq();
	UM2052_Flush_Tx();
	UM2052_CE_High();
}

// UM2052 读写寄存器函数：cmd = code; D = data
void UM2052_wr_cmd(unsigned char cmd,unsigned char D)
{
	UM2052_CS_LOW();  //UM2052_CSN_LOW;
	SPI_SendByte(cmd);
	SPI_SendByte(D);
	UM2052_CS_HIGH(); //UM2052_CSN_HIGH;
}

// 切换UM2052 BANK
void UM2052_Bank_Switch(UM2052_Bank_TypeDef bank)
{
	unsigned char sta;
	
	sta = UM2052_read_byte(UM2052_BANK0_STATUS);
	
	if(bank != UM2052_Bank0)
	{
		if(!(sta & UM2052_Bank1))
		{
			UM2052_wr_cmd(UM2052_ACTIVATE, UM2052_ACTIVATE_DATA);
		}
	}
	else
	{
		if(sta & UM2052_Bank1)
		{
			UM2052_wr_cmd(UM2052_ACTIVATE, UM2052_ACTIVATE_DATA);
		}
	}
}

// UM2052 切换速率
void UM2052_Change_Rate(UM2052_Rate_TypeDef rate)
{
	unsigned char tmp;
	
	tmp = UM2052_read_byte(UM2052_BANK0_RF_SETUP);

	if(rate == Rate_1M)
	{
		tmp &= 0xf7;
		UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
	}
	else if(rate == Rate_2M)
	{
		tmp |= 0x08;
		UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
	}
}

// UM2052 切换信道
void UM2052_Change_CH(unsigned char chn)
{
	if(chn < 0x80)
		UM2052_write_byte(UM2052_BANK0_RF_CH, chn);
}

// UM2052 切换功率
void UM2052_Change_Pwr(UM2052_Pwr_TypeDef pwr)
{
	unsigned char tmp;

	tmp = UM2052_read_byte(UM2052_BANK0_RF_SETUP);
	tmp &= ~0x47;

	switch (pwr)
	{
		case Pwr_8db:
			tmp |= 0x47;
			UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
		break;

		case Pwr_5db:
			tmp |= 0x40;
			UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
		break;

		case Pwr_4db:
			tmp |= 0x07;
			UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
		break;

		case Pwr_0db:
			tmp |= 0x03;
			UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
		break;

		case Pwr_n6db:
			tmp |= 0x01;
			UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
		break;
	
		default: // 默认就设置成0db
			tmp |= 0x03;
			UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
		break;
	}
}

// UM2052 切换地址
void UM2052_Change_Addr(unsigned char *buf, unsigned char len)
{
	if(len <= 6)
	UM2052_wr_buffer(UM2052_BANK0_RX_ADDR_P0, buf, len); // set address
}


/*UM2052 接收数据包函数
buf：读取到的数据存放的地方
return：正常读取之后，返回的是读取到的数据包长度
*/
unsigned char UM2052_ReceivePack(unsigned char *buf)
{
	unsigned char sta;
	unsigned char fifo_sta;
	unsigned char len;

	sta = UM2052_read_byte(UM2052_BANK0_STATUS);

	if(UM2052_STATUS_RX_DR & sta)
	{
		do
		{
			len = UM2052_read_byte(UM2052_R_RX_PL_WID);
			
			if(len <= UM2052_FIFO_MAX_PACK_SIZE)
			{
				UM2052_read_buffer(UM2052_R_RX_PAYLOAD, buf, len);
			}
			else
			{
				UM2052_Flush_Rx();
			}
			
			fifo_sta = UM2052_read_byte(UM2052_BANK0_FIFO_STATUS);
		}while(!(fifo_sta & UM2052_FIFO_STA_RX_EMPTY));/*not empty continue read out*/ 
		
		UM2052_write_byte(UM2052_BANK0_STATUS, sta);/*clear irq*/
		UM2052_Clear_All_Irq();
		UM2052_Flush_Tx();
		UM2052_Flush_Rx();
		return len;
	}

	if(sta & (UM2052_STATUS_RX_DR | UM2052_STATUS_TX_DS | UM2052_STATUS_MAX_RT))
	{
		UM2052_write_byte(UM2052_BANK0_STATUS, sta);/*clear irq*/
	}
	
	return 0;
}


/* UM2052发送数据包函数
  buf:要发送的数据包内容指针 
  len:数据包的长度，从1到32字节 
  cmd: 发送数据包的命令，UM2052_W_TX_PAYLOAD和UM2052_W_TX_PAYLOAD_NOACK
*/
void UM2052_SendPack(unsigned char cmd, unsigned char* buf, unsigned char len)
{
	unsigned char sta;
	
	sta = UM2052_read_byte(UM2052_BANK0_STATUS);
	if(!(sta & UM2052_STATUS_TX_FULL))
	{
		UM2052_wr_buffer(cmd, buf, len);
	}
}
 
// UM2052 切换RF工作模式函数
void UM2052_ModeSwitch(UM2052_ModeTypeDef mod)
{
	unsigned char tmp;
	
	tmp = UM2052_read_byte(UM2052_BANK0_CONFIG);
	if(mod != UM2052_PRX_Mode)
	{
		tmp &= 0xFE;
	}
	else
	{
		tmp |= 0x01;
	}
	UM2052_write_byte(UM2052_BANK0_CONFIG, tmp);

	if(mod == UM2052_Carrier_Mode)
	{
		//tmp = 0Xc7;  // 0x80 | UM2052_read_byte(UM2052_BANK0_RF_SETUP);
		tmp = 0x80 | UM2052_read_byte(UM2052_BANK0_RF_SETUP);
		UM2052_write_byte(UM2052_BANK0_RF_SETUP, tmp);
		/* 注意：最高位为载波使能位，设置了载波模式之后，CE要拉高，载波才会出来；
		   如果不要切换频点，功率等，就不要去在操作RF，否则会看不到载波信号的*/
	}
}

// UM2052 清中断标志
void UM2052_Clear_All_Irq(void)
{
	UM2052_write_byte(UM2052_BANK0_STATUS, 0x70);
}

// UM2052 清空TX FIFO
void UM2052_Flush_Tx(void)
{
	UM2052_Operation(UM2052_FLUSH_TX);
}

// UM2052 清空RX FIFO
void UM2052_Flush_Rx(void)
{
	UM2052_Operation(UM2052_FLUSH_RX);
}

// UM2052 CE拉高
void UM2052_CE_High(void)
{
	UM2052_Operation(UM2052_CMD_CE_HIGH);
}

// UM2052 CE拉低
void UM2052_CE_Low(void)
{
	UM2052_Operation(UM2052_CMD_CE_LOW);
}

// 读取2052接收到的数据包长度的函数
unsigned char UM2052_read_payload_length(void)
{
	return UM2052_read_byte(UM2052_R_RX_PL_WID);
}

// UM2052休眠
void UM2052_Enter_Sleep(void)
{
	unsigned char temp;

	/***********RF进入睡眠的操作************/
	temp = UM2052_read_byte(UM2052_BANK0_PMU_CTL);
	temp &= 0xfc;
	temp |= 0x01;
	UM2052_write_byte(UM2052_BANK0_PMU_CTL, temp); // RF进入deepsleep模式设置
	
	delay_ms(1); // 这个1ms时间是必须要的，要等待RF完成一系列动作
	
	UM2052_write_byte(UM2052_BANK0_CONFIG, 0x80); // 关晶振
}
// UM2052退出休眠
void UM2052_Leave_Sleep(void)
{	
	unsigned char temp;

	/***********RF退出睡眠的操作************/		
	UM2052_write_byte(UM2052_BANK0_CONFIG, 0x83); // 晶体打开
	
	delay_ms(1); // 这个1ms的时间是必须的，等待晶体起振和RF芯片的一系列动作
	
	temp = UM2052_read_byte(UM2052_BANK0_PMU_CTL);
	temp &= 0xfc;
	UM2052_write_byte(UM2052_BANK0_PMU_CTL, temp); // 设置芯片退出deepsleep模式			
}


