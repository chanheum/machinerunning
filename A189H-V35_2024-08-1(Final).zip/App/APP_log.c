
#include	"APP.h"

void log_UART_init(void)
{
	COMx_InitDefine		COMx_InitStructure;					//�ṹ����

	COMx_InitStructure.UART_Mode      = UART_8bit_BRTx;	//ģʽ, UART_ShiftRight,UART_8bit_BRTx,UART_9bit,UART_9bit_BRTx
	COMx_InitStructure.UART_BRT_Use   = BRT_Timer1;			//ѡ�����ʷ�����, BRT_Timer1, BRT_Timer2 (ע��: ����2�̶�ʹ��BRT_Timer2)
	COMx_InitStructure.UART_BaudRate  = 115200ul;			//������, һ�� 110 ~ 115200
	COMx_InitStructure.UART_RxEnable  = ENABLE;				//��������,   ENABLE��DISABLE
	COMx_InitStructure.BaudRateDouble = DISABLE;			//�����ʼӱ�, ENABLE��DISABLE
	UART_Configuration(UART1, &COMx_InitStructure);		//��ʼ������1 UART1,UART2,UART3,UART4
	NVIC_UART1_Init(ENABLE,Priority_1);		//�ж�ʹ��, ENABLE/DISABLE; ���ȼ�(�͵���) Priority_0,Priority_1,Priority_2,Priority_3
	
	P3_MODE_IO_PU(B0000_0011);		//P3.4~P3.7 ����Ϊ׼˫���
}

COM_RX_Struct	COM_RX_User = {0};

void log_SHOW_Task(void)
{
	LED_Display_DUTY_SET(COM_RX_User.DUTY);		//��ʾ�������� 0-7
	LED_Display_DATA_SET(COM_RX_User.DATA);	//��ʾ�������� 
}

//���� ͨѶ
void COM_log_RX(void)
{
	u8 CheckSum, i;
	static u8 cnt7f = 0;
		
	static u8 Com_RX_Cnt = 0;
	static u8 Com_RX_Status = 0;
	static u8 log_RX_Data[10];
	
	while (Com_RX_read != Com_RX_write)
	{
			log_RX_Data[Com_RX_Cnt] = Com_Get_data();
//			TX1_write2buff(log_RX_Data[Com_RX_Cnt]);
		
		if (log_RX_Data[Com_RX_Cnt] == 0x7f)
		{
				cnt7f++;
				if (cnt7f >= 2)
				{
					cnt7f = 0;
//					PrintString1("���ظ�λ");
//					delay_ms(100);
					IAP_CONTR=0xE0;//��λ����	  1110 0000  �������ĳ���
				}
		}
		else 
		{
				cnt7f = 0;
		}
		
		//����״̬��
		switch(Com_RX_Status)
		{
			default : //AA
				Com_RX_Status = 0; Com_RX_Cnt = 0;
				if(log_RX_Data[Com_RX_Cnt]==Com_Head)
				{
					COM_RX_User.Head = log_RX_Data[Com_RX_Cnt];
					Com_RX_Status++,Com_RX_Cnt++;
				}
				break;
				
			case 1:	//55
				if(log_RX_Data[Com_RX_Cnt] == Com_Tial) 
				{
					COM_RX_User.Tial = log_RX_Data[Com_RX_Cnt];
					Com_RX_Status++,Com_RX_Cnt++;
				}
				else  
				{
					Com_RX_Status=0,Com_RX_Cnt=0;
				}
				break;
				
			case 2:
				Com_RX_Cnt++;
				if(Com_RX_Cnt > Com_MAX_data) 
				{
					Com_RX_Status = 10;
					Com_RX_Cnt=0;
				}
				break;
		}
			
		if(Com_RX_Status >= 10)
		{
			Com_RX_Status = 0;
			Com_RX_Cnt = 0;
			
			for(i=Com_CheckSum_Start,CheckSum = 0; i<=Com_CheckSum_Stop ;i++)
			{
				CheckSum += log_RX_Data[i]; //����У���
			}
			
//			TX1_write2buff(CheckSum);
//			TX1_write2buff(log_RX_Data[Com_CheckSum_data]);
			
//			if(CheckSum != log_RX_Data[Com_CheckSum_data]) 
//				return;
			
			COM_RX_User.DUTY = log_RX_Data[2];
			COM_RX_User.DATA[0] = log_RX_Data[3];
			COM_RX_User.DATA[1] = log_RX_Data[4];
			COM_RX_User.DATA[2] = log_RX_Data[5];
			COM_RX_User.DATA[3] = log_RX_Data[6];
			
			log_SHOW_Task();
		}
	}
}

void log_print(void)
{
//	TX1_write2buff(COM0_DC_H);
//	TX1_write2buff(COM1_DC_H);
//	TX1_write2buff(COM2_DC_H);
//	TX1_write2buff(COM3_DC_H);
//	TX1_write2buff('0');
//	PrintString1("�λ���\r\n");
}

