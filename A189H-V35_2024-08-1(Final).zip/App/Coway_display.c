
// 20240729 v34

#include "Coway_display.h"
#include "APP_LED_Display.h"
#include "APP_Show_Display.h"
#include "APP_RF_TXRX.h"
#include "APP_KEY.h"

// Status //////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Mode
#define D_AUTO_MIN   0xA1U
#define D_AUTO_MAX   0xA6U
#define D_FOCUS_MIN  0xB1U
#define D_FOCUS_MAX  0xB3U
#define D_MANUAL_MIN 0xC1U
#define D_MANUAL_MAX 0xC5U
U8 u8Mode = 0U; // 0xA1~A6,B1~B3,C1~C5

// Paring
#define D_DEFAULT_PID 0xFFU
U8 u8Paring = 0U; // 0:None / 1:Paring Start / 2:Paring Clear
U8 u8Pid[2];
U8 u8ParingCheck = 0U; // 0:No Paring / 1:Paring Finished
U8 u8ParingCnt   = 0U;

// Str
#define D_STR_MIN 1U
#define D_STR_MAX 3U
U8 u8Str = 0U; // 1~3

// Heat
#define D_HEAT_MIN 1U
#define D_HEAT_MAX 3U
U8 u8Heat = 0U; // 0~3

// On/Off
U8 u8Power = 0U; // 0,1
U8 u8Ball  = 0U; // 0,1

// Tx
U8 u8Tx      = 0U;
U8 u8KeyData = 0U; // 0x00~0x0C

// Rx data
#define D_TIME_MAX 60U // Max 60mins
U8 u8ReIdTx   = 0U;
U8 u8ReIdRx   = 0U;
U8 u8Retry    = 0U;
U8 u8RetryCnt = 0U;
U8 u8Time     = 0U;
U8 u8Error    = 0U;

// Key input
#define D_LONG_KEY_CNT 15U // 1.5sec
U8 u8Key        = 0U;
U8 u8OldKey     = 0U;
U8 u8LowB       = 0U;
U8 u8LongKeyCnt = 0U;

// Display /////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Display Process
#define D_DISPLAY_COUNT_MAX    135U
#define D_DISPLAY_COUNT_MIN    60U
#define D_DISPLAY_COUNT_CHANGE 35U
U8 u8Display        = 0U;
U8 u8DisplayCnt     = 0U;
U8 u8BallDisplayCnt = 0U;

// LED position 1
#define LED_MANUAL 0x01U
#define LED_FOCUS  0x02U
#define LED_AUTO   0x04U
#define LED_FIX    0x08U
#define LED_HEAT   0x10U
#define LED_STR    0x20U
#define LED_COURSE 0x40U
// LED position 2
#define LED_STEP  0x01U
#define LED_MINS  0x02U
#define LED_LOW_B 0x04U
// Display output
U8 u8Backlight = N_OFF;
U8 u8Digit_1   = E_SEG_NULL;
U8 u8Digit_2   = E_SEG_NULL;
U8 u8Led_1     = 0U;
U8 u8Led_2     = 0U;
extern u8 Password[2];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Display /////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void mPower(void);
static void mMode(void);
static void mStr(void);
static void mHeat(void);
static void mAddTime(void);
static void mBallDn(void);
static void mBallUp(void);
static void mBallFix(void);
static void mTime(void);
static void mPrStart(void);
static void mPrClear(void);
static void mTest(void);
static void mVer(void);
static void MakeTxData(void);
static void LED_ALL_OFF(void);

// First for 7sec
DisplayList_T Display_Mapping_List_A[] =
    { //  Id              LED(Manual  Focus       Auto        Fix         Str         Heat        Course      Step        Mins        Key     Func    )
        {ID_NULL, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x00, C_NULL},

        {ID_POWER_ONOFF, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x01, mPower},
        {ID_PAUSE, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x02, C_NULL},

        {ID_AUTO, CLEAR, CLEAR, LED_AUTO, CLEAR, CLEAR, CLEAR, LED_COURSE, CLEAR, CLEAR, 0x03, mMode},
        {ID_MANUAL, LED_MANUAL, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, LED_COURSE, CLEAR, CLEAR, 0x05, mMode},

        {ID_STR, CLEAR, CLEAR, CLEAR, CLEAR, LED_STR, CLEAR, CLEAR, LED_STEP, CLEAR, 0x09, mStr},
        {ID_HEAT, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, LED_HEAT, CLEAR, LED_STEP, CLEAR, 0x0A, mHeat},

        {ID_ADD_TIME, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, LED_MINS, 0x10, mAddTime},

        {ID_BALL_DN, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x06, mBallDn},
        {ID_BALL_UP, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x08, mBallUp},
        {ID_BALL_FIX, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x07, mBallFix},

        {ID_SOUND, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x11, C_NULL},
        {ID_MOVE_0G, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x0D, C_NULL},
        {ID_LEG_UP, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x0B, C_NULL},
        {ID_LEG_DN, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x0C, C_NULL},
        {ID_BACK_DN, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x0F, C_NULL},
        {ID_BACK_UP, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x0E, C_NULL},

        {ID_FOCUS, CLEAR, LED_FOCUS, CLEAR, CLEAR, CLEAR, CLEAR, LED_COURSE, CLEAR, CLEAR, 0x04, mMode},
        {ID_SWING, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x14, C_NULL},

        {ID_PARING_SET, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x13, mPrStart},
        {ID_PARING_CLR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, C_NULL, mPrClear},
        {ID_SKIP, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, 0x12, C_NULL},
        {ID_ETC, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, C_NULL, C_NULL},
        {ID_TEST, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, CLEAR, C_NULL, mTest},
        {ID_VER, LED_MANUAL, LED_FOCUS, LED_AUTO, LED_FIX, LED_STR, LED_HEAT, LED_COURSE, LED_STEP, LED_MINS, C_NULL, mVer}};
#define SZ_DISPLAY_MAP_LIST_A (sizeof(Display_Mapping_List_A) / sizeof(DisplayList_T))

static void RunDisplay(DisplayList_T *pList)
{
    Action_T pFun;

    u8Led_1   = CLEAR;
    u8Led_2   = CLEAR;
    u8Digit_1 = E_SEG_NULL;
    u8Digit_2 = E_SEG_NULL;

    if (pList->Manual != CLEAR) {
        u8Led_1 |= pList->Manual;
    }
    if (pList->Focus != CLEAR) {
        u8Led_1 |= pList->Focus;
    }
    if (pList->Auto != CLEAR) {
        u8Led_1 |= pList->Auto;
    }
    if (pList->Fix != CLEAR) {
        u8Led_1 |= pList->Fix;
    }
    if (pList->Str != CLEAR) {
        u8Led_1 |= pList->Str;
    }
    if (pList->Heat != CLEAR) {
        u8Led_1 |= pList->Heat;
    }
    if (pList->Course != CLEAR) {
        u8Led_1 |= pList->Course;
    }
    if (pList->Step != CLEAR) {
        u8Led_2 |= pList->Step;
    }
    if (pList->Min != CLEAR) {
        u8Led_2 |= pList->Min;
    }

    pFun = pList->Func;
    if (pFun != C_NULL) {
        pFun();
    }

    if (u8Tx == SET) {
        u8Tx = CLEAR;
        if (pList->Key != C_NULL) {
            u8KeyData = pList->Key;
        } else {
            u8KeyData = 0U;
        }

        if (u8Key == ID_PARING_SET) {
            u8Paring = 1U;
            u8Pid[0] = TH0;
            u8Pid[1] = TL0;
        } else if (u8Key == ID_PARING_CLR) {
            u8Paring = 2U;
            u8Pid[0] = D_DEFAULT_PID;
            u8Pid[1] = D_DEFAULT_PID;
        } else {
            u8Paring = CLEAR;
        }
        Password[0] = u8Pid[0];
        Password[1] = u8Pid[1];
        MakeTxData();
    }
}

static void DisplayFirst(void)
{
    DisplayList_T *pList = C_NULL;
    Action_T *pFun       = C_NULL;
    U8 i                 = 0U;

    pList = Display_Mapping_List_A;
    for (i = 0U; i < SZ_DISPLAY_MAP_LIST_A; i++) {
        if ((pList + i)->Id == u8Display) {
            RunDisplay(pList + i);
            break;
        }
    }

    if (u8Error != CLEAR) {
        u8Digit_1 = E_SEG_E;
        u8Digit_2 = E_SEG_r;
        u8Led_1   = CLEAR;
        u8Led_2   = CLEAR;
    }

    if (u8Power == OFF) {
        u8Digit_1 = E_SEG_o;
        u8Digit_2 = E_SEG_F;
        u8Led_1   = CLEAR;
        u8Led_2   = CLEAR;
    }
}

static void DisplaySecond(void)
{
    U8 pBuf[6];

    // Save Data
    if (u8DisplayCnt == 20U) {
        pBuf[0] = u8Power;
        pBuf[1] = u8Mode;
        pBuf[2] = u8Str;
        pBuf[3] = u8Heat;
        pBuf[4] = u8Ball;
        pBuf[5] = u8ParingCheck;
        EEPROM_SectorErase(EE_ADDRESS);
        EEPROM_write_n(EE_ADDRESS, u8Pid, 2);
        //        EEPROM_SectorErase(EE_ADDRESS_C_1);
        EEPROM_write_n(EE_ADDRESS_C_1, pBuf, 6);
    }

    // Check Off & Err
    if (u8Power == OFF) {
        u8Digit_1 = E_SEG_o;
        u8Digit_2 = E_SEG_F;
        u8Led_1   = CLEAR;
        u8Led_2   = CLEAR;
        return;
    }

    if (u8Error != CLEAR) {
        u8Digit_1 = E_SEG_E;
        u8Digit_2 = E_SEG_r;
        u8Led_1   = CLEAR;
        u8Led_2   = CLEAR;
        return;
    }

    // seg data (digit)
    if (u8Time > D_TIME_MAX) {
        u8Time = D_TIME_MAX;
    }
    u8Digit_1 = GET_DECIMAL_10(u8Time);
    u8Digit_2 = GET_DECIMAL_1(u8Time);

    // led data 1
    u8Led_1 = CLEAR;
    if (u8Mode >= D_AUTO_MIN && u8Mode <= D_AUTO_MAX) {
        u8Led_1 |= LED_AUTO;
    } else if (u8Mode >= D_FOCUS_MIN && u8Mode <= D_FOCUS_MAX) {
        u8Led_1 |= LED_FOCUS;
    } else if (u8Mode >= D_MANUAL_MIN && u8Mode <= D_MANUAL_MAX) {
        u8Led_1 |= LED_MANUAL;
    } else {
    }

    if (u8Ball == SET) {
        u8Led_1 |= LED_FIX;
    }

    if (u8Heat >= D_HEAT_MIN) {
        u8Led_1 |= LED_HEAT;
    }

    // led data 2
    u8Led_2 = CLEAR;
    u8Led_2 |= LED_MINS;
}

static void DisplayHi(void)
{
    u8Digit_1 = E_SEG_H;
    u8Digit_2 = E_SEG_1;
    u8Led_1   = CLEAR;
    u8Led_2   = CLEAR;
}

static void DisplayOff(void)
{
    u8Digit_1        = E_SEG_NULL;
    u8Digit_2        = E_SEG_NULL;
    u8Led_1          = CLEAR;
    u8Led_2          = CLEAR;
    u8Backlight      = N_OFF;
    u8BallDisplayCnt = CLEAR;
    u8Display        = CLEAR;
}

static void LED_ALL_OFF(void)
{
    P16 = 1; // back_led锟截憋拷
    P20 = 0;
    P21 = 0;
    P22 = 0;
    P23 = 0;
}

// Led Control
static void mPower(void)
{
    if (u8Power == SET) {
        u8Digit_1 = E_SEG_H;
        u8Digit_2 = E_SEG_1;
        u8Led_1   = CLEAR;
        u8Led_2   = CLEAR;
    } else {
        u8Digit_1 = E_SEG_o;
        u8Digit_2 = E_SEG_F;
        u8Led_1   = CLEAR;
        u8Led_2   = CLEAR;
    }
}

static void mMode(void)
{
    U8 mu8Seg = 0U;

    mu8Seg = (U8)(u8Mode & 0x0FU);

    u8Digit_1 = E_SEG_NULL;
    u8Digit_2 = mu8Seg;
}

static void mStr(void)
{
    u8Digit_1 = E_SEG_NULL;
    u8Digit_2 = u8Str;
}

static void mHeat(void)
{
    u8Digit_1 = E_SEG_NULL;
    u8Digit_2 = u8Heat;
}

static void mAddTime(void)
{
    u8Digit_1 = E_SEG_1;
    u8Digit_2 = E_SEG_0;
}

static void mBallDn(void)
{
    U8 mCnt = 0U;

    u8BallDisplayCnt++;
    if (u8BallDisplayCnt >= 150U) {
        u8BallDisplayCnt = 0U;
    }

    mCnt = (U8)(u8BallDisplayCnt % 15);

    if (mCnt <= 4U) {
        u8Digit_1 = E_SEG_UPDASH;
        u8Digit_2 = E_SEG_UPDASH;
    } else if (mCnt <= 9U) {
        u8Digit_1 = E_SEG_DASH;
        u8Digit_2 = E_SEG_DASH;
    } else {
        u8Digit_1 = E_SEG_UNDERDASH;
        u8Digit_2 = E_SEG_UNDERDASH;
    }
}

static void mBallUp(void)
{
    U8 mCnt = 0U;

    u8BallDisplayCnt++;
    if (u8BallDisplayCnt >= 150U) {
        u8BallDisplayCnt = 0U;
    }

    mCnt = (U8)(u8BallDisplayCnt % 15);

    if (mCnt <= 4U) {
        u8Digit_1 = E_SEG_UNDERDASH;
        u8Digit_2 = E_SEG_UNDERDASH;
    } else if (mCnt <= 9U) {
        u8Digit_1 = E_SEG_DASH;
        u8Digit_2 = E_SEG_DASH;
    } else {
        u8Digit_1 = E_SEG_UPDASH;
        u8Digit_2 = E_SEG_UPDASH;
    }
}

static void mBallFix(void)
{
    if (u8Ball == SET) {
        u8Led_1 |= LED_FIX;
    }

    if (u8Mode >= D_AUTO_MIN && u8Mode <= D_AUTO_MAX) {
        u8Led_1 |= LED_AUTO;
        u8Led_2 |= LED_MINS;
    } else if (u8Mode >= D_FOCUS_MIN && u8Mode <= D_FOCUS_MAX) {
        u8Led_1 |= LED_FOCUS;
        u8Led_2 |= LED_MINS;
    } else if (u8Mode >= D_MANUAL_MIN && u8Mode <= D_MANUAL_MAX) {
        u8Led_1 |= LED_MANUAL;
        u8Led_2 |= LED_MINS;
    } else {
        u8Led_2 |= LED_MINS;
    }

    if (u8Heat >= D_HEAT_MIN && u8Heat <= D_HEAT_MAX) {
        u8Led_1 |= LED_HEAT;
    }

    if (u8Time > D_TIME_MAX) {
        u8Time = D_TIME_MAX;
    }
    u8Digit_1 = GET_DECIMAL_10(u8Time);
    u8Digit_2 = GET_DECIMAL_1(u8Time);
}

static void mTime(void)
{
    if (u8Ball == SET) {
        u8Led_1 |= LED_FIX;
    }

    if (u8Mode >= D_AUTO_MIN && u8Mode <= D_AUTO_MAX) {
        u8Led_1 |= LED_AUTO;
        u8Led_2 |= LED_MINS;
    } else if (u8Mode >= D_FOCUS_MIN && u8Mode <= D_FOCUS_MAX) {
        u8Led_1 |= LED_FOCUS;
        u8Led_2 |= LED_MINS;
    } else if (u8Mode >= D_MANUAL_MIN && u8Mode <= D_MANUAL_MAX) {
        u8Led_1 |= LED_MANUAL;
        u8Led_2 |= LED_MINS;
    } else {
        u8Led_2 |= LED_MINS;
    }

    if (u8Heat >= D_HEAT_MIN && u8Heat <= D_HEAT_MAX) {
        u8Led_1 |= LED_HEAT;
    }

    if (u8Time > D_TIME_MAX) {
        u8Time = D_TIME_MAX;
    }
    u8Digit_1 = GET_DECIMAL_10(u8Time);
    u8Digit_2 = GET_DECIMAL_1(u8Time);
}

static void mPrStart(void)
{
    u8Digit_1 = E_SEG_P;
    u8Digit_2 = E_SEG_r;
}

static void mPrClear(void)
{
    u8Digit_1 = E_SEG_C;
    u8Digit_2 = E_SEG_L;
}

static void mTest(void)
{
    u8Digit_1 = E_SEG_t;
    u8Digit_2 = E_SEG_t;
}

static void mVer(void)
{
    u8Led_2 |= LED_LOW_B;
    u8Digit_1 = (PROGRAM_VER / 10U);
    u8Digit_2 = (PROGRAM_VER % 10U);
}

static void MakeTxData(void)
{
    static U8 Keybuf[32] = {0};
    U8 CheckSum          = 0U;
    U8 i                 = 0U;

    if (u8Retry != SET) {
        u8ReIdTx++;
        if (u8ReIdTx >= 0xFFU) {
            u8ReIdTx = 0x01U;
        }
    }

    Keybuf[0]  = ASCII_STX;
    Keybuf[1]  = u8Paring;
    Keybuf[2]  = u8Pid[0];
    Keybuf[3]  = u8Pid[1];
    Keybuf[4]  = u8ReIdTx;
    Keybuf[5]  = u8Power;
    Keybuf[6]  = u8Mode;
    Keybuf[7]  = u8Str;
    Keybuf[8]  = u8Heat;
    Keybuf[9]  = u8Ball;
    Keybuf[10] = u8KeyData;

    for (i = 0U; i < 11U; i++) {
        CheckSum += Keybuf[i];
    }

    Keybuf[11] = (U8)CheckSum;
    Keybuf[12] = ASCII_ETX;
    for (i = 0; i < 13; i++) {
        TX1_write2buff(Keybuf[i]);
    }
    RF_IAP_RF_TX(Keybuf, 32);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// While Function
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void KeyProcessC(void)
{
    if (u8LongKeyCnt <= D_LONG_KEY_CNT) {
        u8LongKeyCnt++;
    }

    /*if ( u8Paring != CLEAR )
    {
        u8ParingCnt++;
        if ( GET_DECIMAL_1(u8ParingCnt) == 0U )
        {
            MakeTxData();
        }
    }
    else
    {
        u8ParingCnt = CLEAR;
    }*/

    if (u8ReIdTx != u8ReIdRx) {
        u8Retry = SET;
        u8RetryCnt++;
    } else {
        u8Retry    = CLEAR;
        u8RetryCnt = CLEAR;
    }

    if (u8RetryCnt == 5U || u8RetryCnt == 10U) {
        MakeTxData();
    }
}

static void RxProcessC(void)
{
#ifdef CONFIG_TEST

#else
    if (Wireless_RX.Head != 0x02U || Wireless_RX.Tial != 0x03U) {
        return;
    }

    if (u8Paring != CLEAR) {
        if (u8Pid[0] == Wireless_RX.Paring1 && u8Pid[1] == Wireless_RX.Paring2) {
            //								TX1_write2buff(0xA1);
            if (u8Paring == SET) {
                EEPROM_SectorErase(EE_ADDRESS);
                EEPROM_write_n(EE_ADDRESS, u8Pid, 2);
                //                TX1_write2buff(0xB1);
                u8ParingCheck = SET;
                u8Paring      = CLEAR;
            } else {
                //                TX1_write2buff(0xC1);
                u8ParingCheck = CLEAR;
                u8Paring      = CLEAR;
            }
        }
    }

    u8ReIdRx = Wireless_RX.Data0;
    u8Time   = Wireless_RX.Data1;
    u8Error  = Wireless_RX.Data2;
// Wireless_RX.Data2;
// Wireless_RX.Data3;
#endif
}

static void DisplayProcessC(void) // 100ms
{
    if (u8DisplayCnt == 0U) {
        DisplayOff();
        return;
    }

    if (u8DisplayCnt > 0U) {
        u8DisplayCnt--;
        if (u8DisplayCnt >= D_DISPLAY_COUNT_CHANGE) {
            DisplayFirst();
        } else {
            DisplaySecond();
        }
    }
}

static void KeyInput(U8 mKey)
{
    //		TX1_write2buff(0xbb);
    //		TX1_write2buff(u8Paring);
    if (u8Paring != CLEAR) {
        return;
    }
    //    TX1_write2buff(0xEE);
    //		TX1_write2buff(mKey);
    if (mKey == ID_POWER_ONOFF) {
        if (u8Power == OFF) {
            u8Power = ON;
            u8Mode  = CLEAR;
            u8Str   = D_STR_MIN;
            u8Heat  = CLEAR;
            u8Ball  = CLEAR;
        } else {
            u8Power = OFF;
            u8Mode  = CLEAR;
            u8Str   = D_STR_MIN;
            u8Heat  = CLEAR;
            u8Ball  = CLEAR;
        }
    } else if (mKey == ID_AUTO) {
        if (u8Mode < D_AUTO_MIN || u8Mode >= D_AUTO_MAX) {
            u8Mode = D_AUTO_MIN;
        } else {
            u8Mode++;
        }
    } else if (mKey == ID_FOCUS) {
        if (u8Mode < D_FOCUS_MIN || u8Mode >= D_FOCUS_MAX) {
            u8Mode = D_FOCUS_MIN;
        } else {
            u8Mode++;
        }

    } else if (mKey == ID_MANUAL) {
        if (u8Mode < D_MANUAL_MIN || u8Mode >= D_MANUAL_MAX) {
            u8Mode = D_MANUAL_MIN;
        } else {
            u8Mode++;
        }
    } else if (mKey == ID_STR) {
        if (u8Str < D_STR_MIN || u8Str >= D_STR_MAX) {
            u8Str = D_STR_MIN;
        } else {
            u8Str++;
        }
    } else if (mKey == ID_HEAT) {
        if (u8Heat >= D_HEAT_MAX) {
            u8Heat = OFF;
        } else {
            u8Heat++;
        }
    } else if (mKey == ID_BALL_FIX) {
        if (u8Ball == CLEAR) {
            u8Ball = SET;
        } else {
            u8Ball = CLEAR;
        }
    } else {
    }

    if (mKey == ID_BALL_DN || mKey == ID_BALL_UP) {
        u8DisplayCnt = D_DISPLAY_COUNT_MIN;
    } else {
        u8DisplayCnt = D_DISPLAY_COUNT_MAX;
    }

    // Update
    u8Backlight = N_ON;
    u8Key       = mKey;
    u8Display   = u8Key;
    u8Tx        = SET;
    u8Retry     = CLEAR;
    // u8LowB = mLowB;

    // pop key
    // if ( mKey == ID_SOUND  || mKey == ID_MOVE_0G )
    //{
    // u8Key = CLEAR;
    //    u8Tx = CLEAR;
    //}

    // if power off status
    if (u8Power == OFF) {
        u8Power = OFF;
        u8Mode  = CLEAR;
        u8Str   = D_STR_MIN;
        u8Heat  = CLEAR;
        u8Ball  = CLEAR;

        // u8DisplayCnt = D_DISPLAY_COUNT_CHANGE;
    }
}

static void KeyPushing(void)
{
    // u8DisplayCnt = D_DISPLAY_COUNT_MIN;
}

static void KeyClear(void)
{
    if (u8Paring != CLEAR) {
        return;
    } else {
    }
    u8LongKeyCnt = CLEAR;
    u8Key        = CLEAR;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// iRest use Function
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CowayProcess(void) // 100ms
{
    KeyProcessC();
    RxProcessC();
    DisplayProcessC();
}

void SetKeyInput(U8 mKey, U8 mLowB)
{
    KeyInput(mKey);
}

void SetKeyPushing(void)
{
    KeyPushing();
}
void SetKeyOff(void)
{
    KeyClear();
}

// iRest Get Function
U8 GetCowayDisplayBack(void)
{ // On(1) / Off(0)
    return u8Backlight;
}

U8 GetCowayDisplay0(void) // first
{                         // smgduan
    return u8Digit_1;
}

U8 GetCowayDisplay1(void) // second
{                         // smgduan
    return u8Digit_2;
}

U8 GetCowayDisplay2(void) //
{
    /*
    #define LED_MANUAL    0x01U
    #define LED_AUTO      0x02U
    #define LED_STR       0x04U
    #define LED_HEAT      0x08U
    #define LED_PAUSE     0x10U
    #define LED_STEP      0x40U
    */
    return u8Led_1;
}

U8 GetCowayDisplay3(void)
{
    /*
    #define LED_COURSE    0x01U
    #define LED_MINS      0x02U
    #define LED_LOW_B     0x04U
    */
    return u8Led_2;
}

void SetCowayData(U8 *pBuf)
{
    u8Power       = pBuf[0]; // 0,1
    u8Mode        = pBuf[1]; // 0, 0xA1~6, B1~3, C1~5
    u8Str         = pBuf[2]; // 1~3
    u8Heat        = pBuf[3]; // 0~3
    u8Ball        = pBuf[4]; // 0,1
    u8ParingCheck = pBuf[5]; // 0,1
                             //	if(u8ParingCheck==2)		u8ParingCheck=0;

    if (u8Power > ON) {
        u8Power       = OFF;
        u8Mode        = CLEAR;
        u8Str         = D_STR_MIN;
        u8Heat        = OFF;
        u8Ball        = CLEAR;
        u8ParingCheck = CLEAR;
    }

    TX1_write2buff(0xC3);
    u8Paring = CLEAR; // Coway Added. Because of it does not waked up. when all display is off. (only when Pairing Start or Clear) 2024-07-30 @CH.PARK
}

void SetCowayPid(U8 *pBuf)
{
    if (u8ParingCheck == SET) {
        u8Pid[0] = pBuf[0];
        u8Pid[1] = pBuf[1];
    } else {
        u8Pid[0] = D_DEFAULT_PID;
        u8Pid[1] = D_DEFAULT_PID;
    }
}
