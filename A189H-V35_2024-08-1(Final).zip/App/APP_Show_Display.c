
#include	"APP.h"
#include	"Coway_display.h"

 Wireless_RX_struct 	Wireless_RX;
uint16_t  ballmovecount;
void Show_Display_init(void)
{
	
}
	
void Show_Display_DATA_SET(u8 *np, u8 num)	//��������
{
	u8 *RX_np;
	u8 cnt, i;
	RX_np = &Wireless_RX.Head;
	
	cnt = sizeof(Wireless_RX);
	if(cnt > num) cnt = num;
		
	for(i=0; i<cnt; i++)
	{
		*RX_np = *np;
		RX_np++;
		np++;
	}
	
}

u8 	Dis_Tick = 0, Dis_Type = 0;
u8 	Display_Data[4]=0;

//void Display_Type_Set(Display_ENUM x)
//{
//	Dis_Type = x;
//	Dis_Tick = 0;
//}
extern u8 Keybuf;
void Show_Display_Drive(void) // //100msʱ������һ��
{
	uint8_t i=0, sum = 0, seg=0;
    
	for(i=0;i<4;i++)
	{
		Display_Data[i]=0;
	}

    // Coway
						seg = GetCowayDisplay0();
						Display_Data[0]	=smgduan[seg];
						seg = GetCowayDisplay1();
						Display_Data[1]	=smgduan[seg];
						Display_Data[2]	=GetCowayDisplay2();
						Display_Data[3]	=GetCowayDisplay3();
						Back_LED = GetCowayDisplayBack();

						LED_Display_DATA_SET(&Display_Data);
}




