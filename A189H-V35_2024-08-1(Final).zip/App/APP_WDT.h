
#ifndef __APP_WDT_H_
#define __APP_WDT_H_

#include "config.h"

void Sample_WDT(void);
void WDT_init(void);

#endif

